//
//  myCell1TableViewCell.swift
//  2018051001郑煜test5
//
//  Created by 郑煜 on 2022/3/15.
//

import UIKit

class myCell1TableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

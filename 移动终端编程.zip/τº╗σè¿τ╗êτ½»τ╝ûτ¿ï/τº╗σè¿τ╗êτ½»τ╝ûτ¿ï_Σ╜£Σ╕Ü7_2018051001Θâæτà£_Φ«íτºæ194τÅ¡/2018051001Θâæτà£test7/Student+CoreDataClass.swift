//
//  Student+CoreDataClass.swift
//  2018051001郑煜test7
//
//  Created by 郑煜 on 2022/3/25.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}

//
//  Student+CoreDataClass.swift
//  2018051001郑煜test3
//
//  Created by 郑煜 on 2022/3/8.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}

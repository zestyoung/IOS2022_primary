//
//  data1.swift
//  2018051001郑煜作业6
//
//  Created by 郑煜 on 2022/3/18.
//

class Data{
    
    static let Share = Data()
    var info:String = ""
    var from:String = ""
    
}

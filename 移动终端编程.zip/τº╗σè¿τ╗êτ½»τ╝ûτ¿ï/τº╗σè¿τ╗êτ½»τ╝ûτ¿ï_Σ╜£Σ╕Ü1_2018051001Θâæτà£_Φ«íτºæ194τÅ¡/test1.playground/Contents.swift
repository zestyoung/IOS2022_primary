var sum = 0
for i in 0...20{
    if i%2 == 1{
        sum+=i
    }
}
print("odd sum = \(sum)")
